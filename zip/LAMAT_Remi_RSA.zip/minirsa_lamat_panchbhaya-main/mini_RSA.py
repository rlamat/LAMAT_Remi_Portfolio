import hashlib
import random as rd

def str_to_int(w):
    return int.from_bytes(w.encode(), byteorder='big')

def int_to_str(c):
    s = ""
    q,r = divmod(c,256)
    s = s+str(chr(r)) 
    while q != 0:
        q,r = divmod(q,256) 
        s = s+str(chr(r))
    return s
    
def listeNbPremiers(n):
    liste = []
    for i in range(2,n):
        if estPremier(i):
            liste.append(i)
    return liste

def estPremier(n):
    for i in range(2,n):
        if n%i == 0:
            return False
    return True
    
def pgcd(a,b):
    while b != 0:
        a, b = b, a % b
    return a

def e(phi):
    e=rd.randint(2,phi-1)
    while pgcd(e,phi) != 1:
        e=rd.randint(2,phi-1)
    return e

def d(e,phi):
    d=1
    while (d*e)%phi != 1:
        d=rd.randint(1,phi-1)
    return d
    
def initCles():
    print("Génération des clés, veuillez patienter ...")
    n=10000
    l=listeNbPremiers(int(n))
    
    print("--------------------------------")
    print("Alice :")
    pA=rd.choice(l)
    qA=rd.choice(l)
    while pA<500 & qA<500:
        pA=rd.choice(l)
        qA=rd.choice(l)
    nA=pA*qA
    phiA=(pA-1)*(qA-1)
    eA=e(phiA)
    dA=d(eA,phiA)
    print("La clé publique de Alice est : ",eA,nA)
    print("La clé privée de Alice est : ",dA,nA)
    
    print("--------------------------------")
    print("CA :")
    pCa=rd.choice(l)
    qCa=rd.choice(l)
    while pCa<500 & qCa<500:
        pCa=rd.choice(l)
        qCa=rd.choice(l)
    nCa=pCa*qCa
    phiCa=(pCa-1)*(qCa-1)
    eCa=e(phiCa)
    dCa=d(eCa,phiCa)
    print("La clé publique de CA est : ",eCa,nCa)
    print("La clé privée de CA est : ",dCa,nCa)
    print("--------------------------------")
    return eA,dA,nA,eCa,dCa,nCa


def decoupeMessage(m):
    alphabet = "abcdefghijklmnopqrstuvwxyz"
    l=[]
    l2=[]
    for i in m:
        l.append(alphabet.index(i)+1)
    for y in l:
        if len(str(y))<2:
            l2.append("0"+str(y))
        else:
            l2.append(str(y))
    mess=""
    for z in l2:
        mess=mess+z
    print("Message à chiffrer : ",mess)
    l2=decoupeMessage2(mess)
    return l2

def assemblerMessage(l):
    s=""
    for i in l:
        if len(str(i))<3:
            s=s+"0"+str(i)
        else:
            s=s+str(i)
    return s

def gestionMessage(eA,dA,nA,eCa,dCa,nCa):
    m=input("Enter the message : ")
    messageInitial=m
    empreinte=SHA_256(m)
    print("Empreinte du message : ",empreinte)
    empreinte=chiffrementRSAEmpreinte(empreinte,dA,nA)
    l=decoupeMessage(m)
    messChiffre=chiffrementRSA(l,eCa,nCa)
    messDechiffre=dechiffrementRSA(messChiffre,dCa,nCa)
    messageRetrouve=assemblerMessage(messDechiffre)
    x=int(messageRetrouve)
    tmp=decoupeMessage2(str(x))
    tmp=gestionApresDecoup2(tmp)
    m=retrouverMessage(tmp)
    print("Le message est : ",m)
    verif=verification(empreinte,eA,nA,m)
    if(verif):
        certificat=chiffrementRSA2(eA,dCa,nCa)
        clePubliqueAlice=dechiffrementRSA2(certificat,eCa,nCa)
        print("Certificat pour la clé publique d'Alice : ",certificat," = clé publique d'Alice (",eA,") chiffrée avec la clé privée de CA (",dCa,")")
        print("Clé publique d'Alice : ",clePubliqueAlice," = certificat (",certificat,") déchiffré avec la clé publique de CA (",eCa,")")
        if(clePubliqueAlice==eA):
            print("Le certificat est validé par Bob !")
        else:
            print("Le certificat est invalidé par Bob !")
    print("--------------------------------")

def tabToInt(l):
    s=""
    for i in l:
        if(len(str(i))==3):
            s=s+str(i)
        if(len(str(i))==2):
            s=s+"0"+str(i)
        if(len(str(i))==1):
            s=s+"00"+str(i)
    return int(s)

def verification(empreinte,e,n,m):
    retour=True
    print("--------------------------------")
    empreinte=dechiffrementRSAEmpreinte(empreinte,e,n)
    if empreinte==SHA_256(m):
        print("Vérification empreinte OK")
        print("Génération du certificat :")
    else:
        print("Une erreur est survenue !")
        print("Fin du programme")
        retour=False
    return retour


def decoupeMessage2(m):
    l=[]
    while len(m)>0:
        if(len(m)>=3):
            l.append(m[len(m)-3:])
            m=m[:len(m)-3]
        else:
            l.append(m)
            m=""
    l.reverse()
    return l

def gestionApresDecoup2(l):
    s=""
    for i in l:
        s=s+i
    l2=[]
    for i in range(0,len(s),2):
        l2.append(s[i:i+2])
    return l2

def retrouverMessage(l):
    alphabet = "abcdefghijklmnopqrstuvwxyz"
    l3=completer(l)
    ltemp=[]
    for i in l3:
        a=int(i)-1
        a=a%26
        ltemp.append(alphabet[a])
    m=""
    for i in ltemp:
        m=m+i
    return m

def completer(l):
    l2=[]
    s=""
    for i in l:
        if(len(str(i))==2):
            s="0"+str(i)
        elif len(str(i))==1:
            s="00"+str(i)
        else:
            s=(i)
        l2.append(s)
    return l2

def SHA_256(m):
    return hexToInt(hashlib.sha256(m.encode('utf-8')).hexdigest())

def decouperInt(n):
    l=[]
    tmp=str(n)
    for i in range(len(tmp),0,-3):
        if(i-3<0):
            l.append(int(tmp[0:i]))
        else:
            l.append(int(tmp[i-3:i]))
    l.reverse()
    return l

def chiffrementRSAEmpreinte(m,e,n):
    l=decouperInt(m)
    l2=chiffrementRSA(l,e,n)
    return l2

def dechiffrementRSAEmpreinte(l,d,n):
    l2=[]
    for i in l:
        l2.append(pow(int(i),d,n))
    x=tabToInt(l2)
    return x

def hexToInt(l):
    s=""
    for i in l:
        s=s+str(i)
    return int(s,16)
    
def chiffrementRSA(l,e,n):
    l2=[]
    for i in l:
        assert int(i)<n
        l2.append(pow(int(i),e,n))
        m=""
    for i in l2:
        m+=str(i)
    print("Message chiffré : ",m)
    return l2

def chiffrementRSA2(m,e,n):
    return pow(int(m),e,n)

def dechiffrementRSA(l,d,n):
    l2=[]
    for i in l:
        assert i<n
        l2.append(pow(i,d,n))
        m=""
    for i in l2:
        m+=str(i)
    print("Message déchiffré : ",m)
    return l2

def dechiffrementRSA2(m,d,n):
    return pow(m,d,n)

def simulation():
    print("--------------------------------")
    eA,dA,nA,eCa,dCa,nCa=initCles()
    print("Début de la simulation.")
    print("Simulation de l'envoi d'un message :")
    gestionMessage(eA,dA,nA,eCa,dCa,nCa)
    print("Fin de la simulation.")
    print("--------------------------------")

simulation()